class Operand
{
public:
    virtual ~Operand();
};


class Number:public Operand
{
public:
    Number(double v);
    double value;
};

class Operator:public Operand
{
//Nothing here
};

class Add:public Operand
{
//Nothing here
};

class Subtract:public Operand
{
//Nothing here
};

class Multiply:public Operand
{
//Nothing here
};

class Divide:public Operand
{
//Nothing here
};

class Square:public Operand
{
//Nothing here
};
