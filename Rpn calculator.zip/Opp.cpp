#include "Operand.h"

Operand::~Operand()
{
    //nothing here
}

Number::Number(double v)
        :value(v)
{
    //Nothing here
}
